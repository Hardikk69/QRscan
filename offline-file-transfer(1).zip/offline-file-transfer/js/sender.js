/**
 * Offline File Transfer - Sender Controller
 * Handles file reading, cryptographic hashing, chunking, frame sequencing, and QR rendering.
 */

// Sender State Variables
let currentState = SenderState.IDLE;
let selectedFile = null;
let fileBuffer = null;
let fileHash = '';
let transferId = '';
let chunks = []; // Array of formatted JSON chunk strings
let currentChunkIndex = 0;
let cycleCount = 1;
let transmissionTimer = null;
let frameInterval = CONFIG.DEFAULT_INTERVAL;
let chunkSize = CONFIG.DEFAULT_CHUNK_SIZE;
let errorCorrectionLevel = CONFIG.DEFAULT_CORRECT_LEVEL;

// DOM Elements
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const fileInfoGrid = document.getElementById('fileInfoGrid');
const configRow = document.getElementById('configRow');
const infoFileName = document.getElementById('infoFileName');
const infoFileType = document.getElementById('infoFileType');
const infoFileSize = document.getElementById('infoFileSize');
const infoFileHash = document.getElementById('infoFileHash');
const chunkSizeSelect = document.getElementById('chunkSizeSelect');
const intervalSelect = document.getElementById('intervalSelect');
const btnStartTransfer = document.getElementById('btnStartTransfer');
const btnChangeFile = document.getElementById('btnChangeFile');
const senderStateBadge = document.getElementById('senderStateBadge');

const transmissionCard = document.getElementById('transmissionCard');
const qrCanvas = document.getElementById('qrCanvas');
const chunkCounterText = document.getElementById('chunkCounterText');
const percentageText = document.getElementById('percentageText');
const progressBar = document.getElementById('progressBar');
const cycleBadge = document.getElementById('cycleBadge');
const speedBadge = document.getElementById('speedBadge');
const frameScrubber = document.getElementById('frameScrubber');
const btnPause = document.getElementById('btnPause');
const btnResume = document.getElementById('btnResume');
const btnStop = document.getElementById('btnStop');
const btnRestart = document.getElementById('btnRestart');

/**
 * Updates sender state and synchronizes UI badges and controls.
 */
function setSenderState(newState) {
  currentState = newState;
  senderStateBadge.textContent = newState;
  
  // Badge color mapping
  senderStateBadge.className = 'badge';
  switch (newState) {
    case SenderState.IDLE:
      senderStateBadge.classList.add('badge-neutral');
      break;
    case SenderState.FILE_SELECTED:
    case SenderState.READY:
      senderStateBadge.classList.add('badge-primary');
      break;
    case SenderState.PREPARING:
    case SenderState.PAUSED:
      senderStateBadge.classList.add('badge-warning');
      break;
    case SenderState.TRANSMITTING:
      senderStateBadge.classList.add('badge-success');
      break;
    case SenderState.COMPLETED:
    case SenderState.STOPPED:
      senderStateBadge.classList.add('badge-neutral');
      break;
    case SenderState.ERROR:
      senderStateBadge.classList.add('badge-danger');
      break;
  }
}

/**
 * Handles file selection from file input or drag-and-drop.
 */
async function handleFileSelected(file) {
  if (!file) return;

  if (file.size === 0) {
    alert('The selected file is empty (0 bytes). Please choose a valid file.');
    return;
  }

  // Safety check for excessively large files for screen-to-camera optical transfer
  const MAX_RECOMMENDED = 15 * 1024 * 1024; // 15MB
  if (file.size > MAX_RECOMMENDED) {
    const proceed = confirm(
      `File size is ${formatBytes(file.size)}. Transmitting files over 15 MB optically via screen-to-camera will take several thousand QR frames. Do you wish to continue?`
    );
    if (!proceed) return;
  }

  selectedFile = file;
  setSenderState(SenderState.PREPARING);

  // Update file info display
  infoFileName.textContent = file.name;
  infoFileType.textContent = file.type || 'application/octet-stream';
  infoFileSize.textContent = formatBytes(file.size);
  infoFileHash.textContent = 'Computing SHA-256...';
  fileInfoGrid.style.display = 'grid';
  configRow.style.display = 'grid';
  btnChangeFile.style.display = 'inline-flex';
  btnStartTransfer.disabled = true;

  try {
    // Read file as ArrayBuffer
    fileBuffer = await readFileAsArrayBuffer(file);
    
    // Compute SHA-256 integrity hash
    fileHash = await computeSHA256(fileBuffer);
    infoFileHash.textContent = truncateMiddle(fileHash, 10, 10);
    infoFileHash.title = `Full SHA-256: ${fileHash}`;

    // Prepare chunks
    prepareChunks();
    setSenderState(SenderState.READY);
    btnStartTransfer.disabled = false;
  } catch (err) {
    console.error('File reading or hashing error:', err);
    alert('Failed to read or process the selected file: ' + err.message);
    setSenderState(SenderState.ERROR);
  }
}

/**
 * Reads a File object into an ArrayBuffer via Promise.
 */
function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('FileReader error while reading file.'));
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Splits the file buffer into binary chunks and formats each as a JSON frame.
 */
function prepareChunks() {
  if (!fileBuffer || !selectedFile) return;

  chunkSize = parseInt(chunkSizeSelect.value, 10) || CONFIG.DEFAULT_CHUNK_SIZE;
  transferId = generateTransferId();
  chunks = [];

  const totalBytes = fileBuffer.byteLength;
  const totalChunks = Math.ceil(totalBytes / chunkSize);

  for (let i = 0; i < totalChunks; i++) {
    const start = i * chunkSize;
    const end = Math.min(start + chunkSize, totalBytes);
    const chunkSlice = fileBuffer.slice(start, end);
    const base64Data = arrayBufferToBase64(chunkSlice);

    const chunkPayload = {
      protocol: PROTOCOL_ID,
      transferId: transferId,
      fileName: selectedFile.name,
      fileType: selectedFile.type || 'application/octet-stream',
      fileSize: selectedFile.size,
      fileHash: fileHash,
      chunkIndex: i,
      totalChunks: totalChunks,
      data: base64Data
    };

    chunks.push(JSON.stringify(chunkPayload));
  }

  frameScrubber.max = totalChunks - 1;
  frameScrubber.value = 0;
  currentChunkIndex = 0;
  cycleCount = 1;

  console.log(`Prepared ${chunks.length} chunks for file ${selectedFile.name} (Chunk size: ${chunkSize} bytes)`);
}

/**
 * Renders a specific chunk index onto the canvas.
 */
function renderChunk(index) {
  if (!chunks || chunks.length === 0 || index < 0 || index >= chunks.length) return;

  currentChunkIndex = index;
  const payload = chunks[index];

  // Render QR to canvas using QRCode library
  if (typeof QRCode !== 'undefined' && QRCode.toCanvas) {
    QRCode.toCanvas(qrCanvas, payload, {
      width: 320,
      margin: 2,
      errorCorrectionLevel: errorCorrectionLevel,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    }, (error) => {
      if (error) {
        console.error('QR rendering error:', error);
      }
    });
  } else {
    console.error('QRCode library is unavailable.');
  }

  // Update UI Progress
  const total = chunks.length;
  chunkCounterText.textContent = `Chunk ${index + 1} / ${total}`;
  const pct = Math.round(((index + 1) / total) * 100);
  percentageText.textContent = `${pct}% Complete`;
  progressBar.style.width = `${pct}%`;
  frameScrubber.value = index;
  cycleBadge.textContent = `Cycle: ${cycleCount}`;
}

/**
 * Advances to the next chunk in sequence; loops back to start for repeated cycles.
 */
function advanceChunk() {
  let nextIndex = currentChunkIndex + 1;
  if (nextIndex >= chunks.length) {
    // Completed a full transmission cycle, loop back to chunk 0
    cycleCount++;
    nextIndex = 0;
    cycleBadge.textContent = `Cycle: ${cycleCount}`;
  }
  renderChunk(nextIndex);
}

/**
 * Starts frame transmission sequence.
 */
function startTransmission() {
  if (chunks.length === 0) {
    prepareChunks();
  }

  transmissionCard.style.display = 'block';
  transmissionCard.scrollIntoView({ behavior: 'smooth', block: 'center' });

  frameInterval = parseInt(intervalSelect.value, 10) || CONFIG.DEFAULT_INTERVAL;
  speedBadge.textContent = `${frameInterval} ms`;

  currentChunkIndex = 0;
  cycleCount = 1;
  renderChunk(0);

  clearInterval(transmissionTimer);
  transmissionTimer = setInterval(advanceChunk, frameInterval);

  setSenderState(SenderState.TRANSMITTING);
  btnPause.style.display = 'inline-flex';
  btnResume.style.display = 'none';
}

/**
 * Pauses frame transmission.
 */
function pauseTransmission() {
  if (currentState !== SenderState.TRANSMITTING) return;
  clearInterval(transmissionTimer);
  transmissionTimer = null;
  setSenderState(SenderState.PAUSED);
  btnPause.style.display = 'none';
  btnResume.style.display = 'inline-flex';
}

/**
 * Resumes frame transmission from current chunk.
 */
function resumeTransmission() {
  if (currentState !== SenderState.PAUSED) return;
  frameInterval = parseInt(intervalSelect.value, 10) || CONFIG.DEFAULT_INTERVAL;
  speedBadge.textContent = `${frameInterval} ms`;

  clearInterval(transmissionTimer);
  transmissionTimer = setInterval(advanceChunk, frameInterval);

  setSenderState(SenderState.TRANSMITTING);
  btnPause.style.display = 'inline-flex';
  btnResume.style.display = 'none';
}

/**
 * Stops transmission and clears timers.
 */
function stopTransmission() {
  clearInterval(transmissionTimer);
  transmissionTimer = null;
  setSenderState(SenderState.STOPPED);
  btnPause.style.display = 'none';
  btnResume.style.display = 'inline-flex';
}

/**
 * Restarts transmission cycle from chunk 0.
 */
function restartCycle() {
  cycleCount = 1;
  renderChunk(0);
}

// -------------------------------------------------------------
// Event Listeners Setup
// -------------------------------------------------------------

// Drop zone clicks open file input
dropZone.addEventListener('click', () => fileInput.click());

// Drag & drop file handlers
dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.classList.add('dragover');
});

dropZone.addEventListener('dragleave', () => {
  dropZone.classList.remove('dragover');
});

dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropZone.classList.remove('dragover');
  if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
    handleFileSelected(e.dataTransfer.files[0]);
  }
});

// File input change
fileInput.addEventListener('change', (e) => {
  if (e.target.files && e.target.files.length > 0) {
    handleFileSelected(e.target.files[0]);
  }
});

// Change file button
btnChangeFile.addEventListener('click', () => {
  stopTransmission();
  fileInput.value = '';
  fileInput.click();
});

// Chunk size tuning change
chunkSizeSelect.addEventListener('change', () => {
  if (selectedFile && fileBuffer) {
    prepareChunks();
    if (currentState === SenderState.TRANSMITTING) {
      renderChunk(0);
    }
  }
});

// Interval speed change
intervalSelect.addEventListener('change', () => {
  frameInterval = parseInt(intervalSelect.value, 10) || CONFIG.DEFAULT_INTERVAL;
  speedBadge.textContent = `${frameInterval} ms`;
  if (currentState === SenderState.TRANSMITTING) {
    clearInterval(transmissionTimer);
    transmissionTimer = setInterval(advanceChunk, frameInterval);
  }
});

// Control buttons
btnStartTransfer.addEventListener('click', startTransmission);
btnPause.addEventListener('click', pauseTransmission);
btnResume.addEventListener('click', resumeTransmission);
btnStop.addEventListener('click', stopTransmission);
btnRestart.addEventListener('click', restartCycle);

// Manual frame scrubber
frameScrubber.addEventListener('input', (e) => {
  pauseTransmission();
  const index = parseInt(e.target.value, 10);
  renderChunk(index);
});

// Initial state setup
setSenderState(SenderState.IDLE);
