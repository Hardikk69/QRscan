/**
 * Automated Core Logic Test Suite
 * Validates binary chunking, Base64 encoding/decoding, SHA-256 verification,
 * deduplication, and out-of-order reassembly.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Polyfill Web Crypto for Node.js if needed
if (!global.crypto) {
  global.crypto = crypto.webcrypto;
}

const common = require('../js/common.js');

let passedTests = 0;
let totalTests = 0;

function assert(condition, message) {
  totalTests++;
  if (condition) {
    console.log(`  ✓ PASS: ${message}`);
    passedTests++;
  } else {
    console.error(`  ✗ FAIL: ${message}`);
    process.exitCode = 1;
  }
}

async function runTests() {
  console.log('========================================================');
  console.log('Running Offline File Transfer Core Verification Tests...');
  console.log('========================================================\n');

  // Test 1: Base64 and Binary Roundtrip
  console.log('Test 1: Binary <-> Base64 Roundtrip Fidelity');
  const originalBytes = new Uint8Array([0, 1, 2, 255, 254, 128, 64, 32, 16, 8, 4, 2, 1]);
  const base64Str = common.arrayBufferToBase64(originalBytes);
  const decodedBytes = common.base64ToUint8Array(base64Str);
  assert(decodedBytes.length === originalBytes.length, 'Decoded byte array length matches original');
  let match = true;
  for (let i = 0; i < originalBytes.length; i++) {
    if (decodedBytes[i] !== originalBytes[i]) match = false;
  }
  assert(match, 'Decoded byte content matches original byte-for-byte');

  // Test 2: Large Random Binary Buffer Roundtrip (Simulating 64KB file)
  console.log('\nTest 2: Large Binary Buffer (64KB Random Data)');
  const randomBuffer = crypto.randomBytes(65536);
  const randomUint8 = new Uint8Array(randomBuffer);
  const randomB64 = common.arrayBufferToBase64(randomUint8);
  const restoredUint8 = common.base64ToUint8Array(randomB64);
  assert(Buffer.from(restoredUint8).equals(randomBuffer), '64KB binary buffer restored without corruption');

  // Test 3: SHA-256 Web Crypto Implementation
  console.log('\nTest 3: SHA-256 Crypto Computation');
  const testString = 'Hello Offline Camera File Transfer';
  const testBuf = Buffer.from(testString, 'utf8');
  const expectedHash = crypto.createHash('sha256').update(testBuf).digest('hex');
  const computedHash = await common.computeSHA256(testBuf);
  assert(computedHash === expectedHash, `SHA-256 hash matches expected (${computedHash.substring(0, 12)}...)`);

  // Test 4: Chunking and Reassembly with Metadata
  console.log('\nTest 4: Chunking, JSON Framing, and Reassembly');
  const testFileSize = 2450; // Will result in 5 chunks of 500 bytes (last one 450 bytes)
  const testData = crypto.randomBytes(testFileSize);
  const testFileHash = crypto.createHash('sha256').update(testData).digest('hex');
  const chunkSize = 500;
  const totalChunks = Math.ceil(testFileSize / chunkSize);
  const transferId = common.generateTransferId();

  // Create chunks as the sender does
  const chunks = [];
  for (let i = 0; i < totalChunks; i++) {
    const slice = testData.subarray(i * chunkSize, Math.min((i + 1) * chunkSize, testFileSize));
    const payload = {
      protocol: common.PROTOCOL_ID,
      transferId: transferId,
      fileName: 'test_document.bin',
      fileType: 'application/octet-stream',
      fileSize: testFileSize,
      fileHash: testFileHash,
      chunkIndex: i,
      totalChunks: totalChunks,
      data: common.arrayBufferToBase64(slice)
    };
    chunks.push(JSON.stringify(payload));
  }

  assert(chunks.length === 5, `Created exactly 5 chunks (expected ${totalChunks})`);

  // Test 5: Out-of-Order Arrival and Deduplication
  console.log('\nTest 5: Out-of-Order Scans and Duplicate Filtering');
  const simulatedScans = [
    chunks[1], // Arrives first!
    chunks[1], // Duplicate!
    chunks[1], // Duplicate!
    chunks[3],
    chunks[0],
    chunks[3], // Duplicate!
    chunks[4],
    chunks[2]  // Last missing chunk arrives!
  ];

  const receiverMap = new Map();
  let duplicatesIgnored = 0;

  for (const scanJson of simulatedScans) {
    const parsed = JSON.parse(scanJson);
    if (parsed.protocol !== common.PROTOCOL_ID) continue;
    if (receiverMap.has(parsed.chunkIndex)) {
      duplicatesIgnored++;
      continue;
    }
    receiverMap.set(parsed.chunkIndex, common.base64ToUint8Array(parsed.data));
  }

  assert(duplicatesIgnored === 3, `Ignored 3 duplicate frames (got ${duplicatesIgnored})`);
  assert(receiverMap.size === totalChunks, `Stored all ${totalChunks} unique chunks despite out-of-order arrival`);

  // Test 6: Strict Reassembly and SHA-256 Hash Verification
  console.log('\nTest 6: Strict Reassembly and SHA-256 Verification');
  const reconstructedParts = [];
  for (let i = 0; i < totalChunks; i++) {
    reconstructedParts.push(receiverMap.get(i));
  }
  const reconstructedBuffer = Buffer.concat(reconstructedParts);
  const reconstructedHash = crypto.createHash('sha256').update(reconstructedBuffer).digest('hex');

  assert(reconstructedBuffer.equals(testData), 'Reconstructed file buffer equals original test data');
  assert(reconstructedHash === testFileHash, 'Reconstructed SHA-256 hash matches sender hash exactly');

  // Test 7: Corruption / Tamper Detection
  console.log('\nTest 7: Tamper / Corruption Detection');
  reconstructedParts[0][0] ^= 0xFF; // Flip bit in first byte
  const corruptedBuffer = Buffer.concat(reconstructedParts);
  const corruptedHash = crypto.createHash('sha256').update(corruptedBuffer).digest('hex');
  assert(corruptedHash !== testFileHash, 'Tampered data generates mismatched hash and is successfully rejected');

  console.log('\n========================================================');
  console.log(`Test Results: ${passedTests} / ${totalTests} assertions passed!`);
  console.log('========================================================\n');
}

runTests().catch(err => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
