/**
 * Offline File Transfer - Common Module
 * Protocol definitions, binary conversion, SHA-256 integrity, and shared utilities.
 * 
 * SECURITY & PRIVACY NOTE:
 * No file data is uploaded to a server or external cloud.
 * Transfer happens entirely through optical QR codes displayed on the sender screen
 * and captured by the receiver camera.
 */

// Protocol Identifier
const PROTOCOL_ID = 'OFFLINE_TRANSFER_V1';

// Default configuration values
const CONFIG = {
  DEFAULT_CHUNK_SIZE: 500,     // Conservative byte size for reliable QR scanning
  DEFAULT_INTERVAL: 800,       // Milliseconds per QR frame
  DEFAULT_CORRECT_LEVEL: 'M',  // QR Error correction: L (7%), M (15%), Q (25%), H (30%)
  MIN_CHUNK_SIZE: 150,
  MAX_CHUNK_SIZE: 1200,
  MIN_INTERVAL: 300,
  MAX_INTERVAL: 3000
};

// State Machine for Sender
const SenderState = Object.freeze({
  IDLE: 'IDLE',
  FILE_SELECTED: 'FILE_SELECTED',
  PREPARING: 'PREPARING',
  READY: 'READY',
  TRANSMITTING: 'TRANSMITTING',
  PAUSED: 'PAUSED',
  COMPLETED: 'COMPLETED',
  STOPPED: 'STOPPED',
  ERROR: 'ERROR'
});

// State Machine for Receiver
const ReceiverState = Object.freeze({
  WAITING: 'WAITING',
  SCANNING: 'SCANNING',
  RECEIVING: 'RECEIVING',
  RECONSTRUCTING: 'RECONSTRUCTING',
  VERIFYING: 'VERIFYING',
  COMPLETED: 'COMPLETED',
  ERROR: 'ERROR'
});

/**
 * Converts an ArrayBuffer or Uint8Array to a Base64 string.
 * Uses chunked processing to prevent call stack size overflow on large buffers.
 * 
 * @param {ArrayBuffer|Uint8Array} buffer 
 * @returns {string} Base64 encoded string
 */
function arrayBufferToBase64(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const len = bytes.byteLength;
  const CHUNK_SIZE = 0x8000; // 32KB chunks
  let binary = '';
  
  for (let i = 0; i < len; i += CHUNK_SIZE) {
    const chunk = bytes.subarray(i, Math.min(i + CHUNK_SIZE, len));
    binary += String.fromCharCode.apply(null, chunk);
  }
  return btoa(binary);
}

/**
 * Converts a Base64 string back into a Uint8Array byte buffer.
 * 
 * @param {string} base64 
 * @returns {Uint8Array} Byte array
 */
function base64ToUint8Array(base64) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Computes SHA-256 hash of an ArrayBuffer or Uint8Array using the Web Crypto API.
 * 
 * @param {ArrayBuffer|Uint8Array} buffer 
 * @returns {Promise<string>} Hex string representation of SHA-256 hash
 */
async function computeSHA256(buffer) {
  // Web Crypto digest accepts any BufferSource (ArrayBuffer or ArrayBufferView)
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Formats a byte size into a human-readable string (KB, MB, GB).
 * 
 * @param {number} bytes 
 * @param {number} decimals 
 * @returns {string} Formatted size
 */
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  if (bytes < 0 || isNaN(bytes)) return 'Unknown';
  
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/**
 * Generates a unique transfer ID for a session.
 * 
 * @returns {string} Unique transfer ID
 */
function generateTransferId() {
  const timestamp = Date.now().toString(36);
  const randomPart = Math.random().toString(36).substring(2, 8);
  return `tx_${timestamp}_${randomPart}`;
}

/**
 * Truncates a string with an ellipsis in the middle (ideal for hashes).
 * 
 * @param {string} str 
 * @param {number} frontChars 
 * @param {number} backChars 
 * @returns {string} Truncated string
 */
function truncateMiddle(str, frontChars = 8, backChars = 8) {
  if (!str) return '';
  if (str.length <= frontChars + backChars + 3) return str;
  return `${str.substring(0, frontChars)}...${str.substring(str.length - backChars)}`;
}

/**
 * Plays a short, pleasant notification chirp using the Web Audio API.
 * Does not require any external audio files.
 * 
 * @param {number} frequency Frequency in Hz
 * @param {number} duration Duration in seconds
 */
let audioCtx = null;
function playNotificationChirp(frequency = 880, duration = 0.08) {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    
    if (!audioCtx) {
      audioCtx = new AudioContext();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(frequency, audioCtx.currentTime);
    
    gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
    
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (e) {
    // Audio may be blocked until user interaction or disabled; silently ignore
  }
}

/**
 * Triggers short haptic vibration on mobile devices if supported.
 * 
 * @param {number} ms Duration in milliseconds
 */
function triggerHaptic(ms = 40) {
  if ('vibrate' in navigator) {
    try {
      navigator.vibrate(ms);
    } catch (e) {
      // Ignore vibration errors
    }
  }
}

// Export for Node.js testing environments if module is defined
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PROTOCOL_ID,
    CONFIG,
    SenderState,
    ReceiverState,
    arrayBufferToBase64,
    base64ToUint8Array,
    computeSHA256,
    formatBytes,
    generateTransferId,
    truncateMiddle
  };
}
