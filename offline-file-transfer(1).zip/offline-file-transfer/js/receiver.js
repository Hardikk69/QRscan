/**
 * Offline File Transfer - Receiver Controller
 * Handles camera initialization, QR frame detection, deduplication,
 * missing chunk tracking, file reconstruction, and SHA-256 verification.
 */

// Receiver State Variables
let currentRxState = ReceiverState.WAITING;
let html5QrCode = null;
let isScanning = false;
let currentTransferId = null;
let fileMetadata = null;
let receivedChunks = new Map(); // Map<chunkIndex, Uint8Array>
let duplicateScans = 0;
let reconstructedBlobUrl = null;

// DOM Elements
const receiverStateBadge = document.getElementById('receiverStateBadge');
const cameraSelect = document.getElementById('cameraSelect');
const chkAudioFeedback = document.getElementById('chkAudioFeedback');
const btnStartCamera = document.getElementById('btnStartCamera');
const btnStopCamera = document.getElementById('btnStopCamera');
const btnResetTransfer = document.getElementById('btnResetTransfer');
const cameraHelpBox = document.getElementById('cameraHelpBox');

const transferProgressCard = document.getElementById('transferProgressCard');
const chunkRateBadge = document.getElementById('chunkRateBadge');
const rxFileName = document.getElementById('rxFileName');
const rxFileType = document.getElementById('rxFileType');
const rxFileSize = document.getElementById('rxFileSize');
const rxFileHash = document.getElementById('rxFileHash');
const rxProgressText = document.getElementById('rxProgressText');
const rxMissingText = document.getElementById('rxMissingText');
const rxProgressBar = document.getElementById('rxProgressBar');
const missingChunksBox = document.getElementById('missingChunksBox');
const missingChunksList = document.getElementById('missingChunksList');
const duplicateCounterText = document.getElementById('duplicateCounterText');
const transferIdText = document.getElementById('transferIdText');

const downloadCard = document.getElementById('downloadCard');
const verificationBanner = document.getElementById('verificationBanner');
const finalFileName = document.getElementById('finalFileName');
const finalFileSize = document.getElementById('finalFileSize');
const finalFileHash = document.getElementById('finalFileHash');
const btnDownloadFile = document.getElementById('btnDownloadFile');
const btnReceiveAnother = document.getElementById('btnReceiveAnother');

/**
 * Updates receiver state and badge styling.
 */
function setReceiverState(newState) {
  currentRxState = newState;
  receiverStateBadge.textContent = newState;
  
  receiverStateBadge.className = 'badge';
  switch (newState) {
    case ReceiverState.WAITING:
      receiverStateBadge.classList.add('badge-neutral');
      break;
    case ReceiverState.SCANNING:
      receiverStateBadge.classList.add('badge-primary');
      break;
    case ReceiverState.RECEIVING:
      receiverStateBadge.classList.add('badge-primary');
      break;
    case ReceiverState.RECONSTRUCTING:
    case ReceiverState.VERIFYING:
      receiverStateBadge.classList.add('badge-warning');
      break;
    case ReceiverState.COMPLETED:
      receiverStateBadge.classList.add('badge-success');
      break;
    case ReceiverState.ERROR:
      receiverStateBadge.classList.add('badge-danger');
      break;
  }
}

/**
 * Discovers and populates available video cameras in the select dropdown.
 */
async function enumerateCameras() {
  try {
    if (typeof Html5Qrcode === 'undefined') {
      console.warn('Html5Qrcode library not loaded yet.');
      return;
    }

    const devices = await Html5Qrcode.getCameras();
    cameraSelect.innerHTML = '';

    if (!devices || devices.length === 0) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'No camera devices detected';
      cameraSelect.appendChild(opt);
      return;
    }

    let defaultIndex = 0;
    devices.forEach((device, index) => {
      const opt = document.createElement('option');
      opt.value = device.id;
      opt.textContent = device.label || `Camera ${index + 1}`;
      
      // Auto-select rear/environment camera on mobile
      const label = (device.label || '').toLowerCase();
      if (label.includes('back') || label.includes('rear') || label.includes('environment')) {
        defaultIndex = index;
      }
      cameraSelect.appendChild(opt);
    });

    cameraSelect.selectedIndex = defaultIndex;
  } catch (err) {
    console.warn('Unable to enumerate cameras:', err);
    cameraSelect.innerHTML = '<option value="">Default Camera</option>';
  }
}

/**
 * Starts the camera preview and QR scanner.
 */
async function startCamera() {
  try {
    if (isScanning) return;

    if (typeof Html5Qrcode === 'undefined') {
      alert('Html5Qrcode library is still loading or unavailable.');
      return;
    }

    if (!html5QrCode) {
      html5QrCode = new Html5Qrcode('reader');
    }

    const selectedCameraId = cameraSelect.value;
    const cameraConfig = selectedCameraId
      ? { deviceId: { exact: selectedCameraId } }
      : { facingMode: 'environment' };

    const config = {
      fps: 20, // 20 scans/sec for rapid capture
      qrbox: (viewfinderWidth, viewfinderHeight) => {
        const edgeSize = Math.floor(Math.min(viewfinderWidth, viewfinderHeight) * 0.85);
        return { width: edgeSize, height: edgeSize };
      },
      aspectRatio: 1.0,
      experimentalFeatures: {
        useBarCodeDetectorIfSupported: true
      }
    };

    setReceiverState(ReceiverState.SCANNING);

    await html5QrCode.start(
      cameraConfig,
      config,
      onScanSuccess,
      onScanFailure
    );

    isScanning = true;
    btnStartCamera.style.display = 'none';
    btnStopCamera.style.display = 'inline-flex';
    cameraHelpBox.style.display = 'none';
  } catch (err) {
    console.error('Camera start failure:', err);
    setReceiverState(ReceiverState.ERROR);
    alert('Failed to start camera: ' + (err.message || err));
  }
}

/**
 * Stops camera preview and scanner.
 */
async function stopCamera() {
  if (html5QrCode && isScanning) {
    try {
      await html5QrCode.stop();
      isScanning = false;
      btnStartCamera.style.display = 'inline-flex';
      btnStopCamera.style.display = 'none';
      if (currentRxState === ReceiverState.SCANNING) {
        setReceiverState(ReceiverState.WAITING);
      }
    } catch (err) {
      console.warn('Error stopping camera:', err);
    }
  }
}

/**
 * Handler for scanned QR code.
 */
function onScanSuccess(decodedText) {
  if (!decodedText || currentRxState === ReceiverState.COMPLETED) return;

  let payload;
  try {
    payload = JSON.parse(decodedText);
  } catch (e) {
    // Silently ignore non-JSON or foreign QR codes
    return;
  }

  // 1. Validate protocol identifier
  if (!payload || payload.protocol !== PROTOCOL_ID) {
    return; // Ignore foreign QR codes
  }

  // 2. Validate transfer ID
  if (!currentTransferId) {
    // First valid chunk of a new transfer detected!
    currentTransferId = payload.transferId;
    fileMetadata = {
      transferId: payload.transferId,
      fileName: payload.fileName || 'transfer_file',
      fileType: payload.fileType || 'application/octet-stream',
      fileSize: payload.fileSize || 0,
      fileHash: payload.fileHash || '',
      totalChunks: payload.totalChunks || 1
    };

    // Update metadata UI
    rxFileName.textContent = fileMetadata.fileName;
    rxFileType.textContent = fileMetadata.fileType;
    rxFileSize.textContent = formatBytes(fileMetadata.fileSize);
    rxFileHash.textContent = truncateMiddle(fileMetadata.fileHash, 8, 8);
    rxFileHash.title = fileMetadata.fileHash;
    transferIdText.textContent = `ID: ${fileMetadata.transferId}`;

    transferProgressCard.style.display = 'block';
    setReceiverState(ReceiverState.RECEIVING);
  } else if (payload.transferId !== currentTransferId) {
    // Chunk belongs to a different transfer session
    console.warn('Received chunk from different transfer session; ignoring.');
    return;
  }

  const chunkIndex = payload.chunkIndex;
  const totalChunks = payload.totalChunks;

  // 3. Duplicate handling: ignore already received chunk
  if (receivedChunks.has(chunkIndex)) {
    duplicateScans++;
    duplicateCounterText.textContent = `Duplicate scans skipped: ${duplicateScans}`;
    return;
  }

  // 4. Decode binary chunk data
  try {
    const chunkBytes = base64ToUint8Array(payload.data);
    receivedChunks.set(chunkIndex, chunkBytes);

    // Subtle audio / haptic chirp for user feedback
    if (chkAudioFeedback.checked) {
      playNotificationChirp(880, 0.04);
      triggerHaptic(25);
    }
  } catch (decodeErr) {
    console.error(`Failed to decode chunk ${chunkIndex}:`, decodeErr);
    return;
  }

  // 5. Update progress & calculate missing chunks
  updateReceiverProgress(totalChunks);

  // 6. Check if transfer is complete
  if (receivedChunks.size === totalChunks) {
    handleTransferComplete();
  }
}

/**
 * Scan failure callback (called when frame does not contain a QR code).
 */
function onScanFailure(error) {
  // Frequent no-op per video frame
}

/**
 * Updates UI progress bar, counters, and missing chunk pills.
 */
function updateReceiverProgress(totalChunks) {
  const receivedCount = receivedChunks.size;
  const pct = Math.round((receivedCount / totalChunks) * 100);

  rxProgressText.textContent = `${receivedCount} / ${totalChunks} chunks (${pct}%)`;
  rxProgressBar.style.width = `${pct}%`;

  // Determine missing chunks
  const missing = [];
  for (let i = 0; i < totalChunks; i++) {
    if (!receivedChunks.has(i)) {
      missing.push(i);
    }
  }

  if (missing.length > 0 && receivedCount > 0) {
    rxMissingText.textContent = `Missing: ${missing.length}`;
    missingChunksBox.style.display = 'block';

    // Show up to 25 missing chunk badges
    missingChunksList.innerHTML = '';
    const displayMissing = missing.slice(0, 25);
    displayMissing.forEach(idx => {
      const pill = document.createElement('span');
      pill.className = 'chunk-pill';
      pill.textContent = `#${idx + 1}`;
      missingChunksList.appendChild(pill);
    });

    if (missing.length > 25) {
      const more = document.createElement('span');
      more.className = 'chunk-pill';
      more.textContent = `+${missing.length - 25} more`;
      missingChunksList.appendChild(more);
    }
  } else {
    rxMissingText.textContent = 'All chunks received!';
    rxMissingText.style.color = 'var(--success)';
    missingChunksBox.style.display = 'none';
  }
}

/**
 * Reconstructs the complete file, verifies SHA-256 hash, and generates download link.
 */
async function handleTransferComplete() {
  console.log('All chunks received! Reconstructing file...');
  
  // Stop camera to release hardware resources
  await stopCamera();

  setReceiverState(ReceiverState.RECONSTRUCTING);

  try {
    const totalChunks = fileMetadata.totalChunks;
    const parts = [];

    // Assemble parts in strict index order (0 to totalChunks - 1)
    for (let i = 0; i < totalChunks; i++) {
      const chunkBytes = receivedChunks.get(i);
      if (!chunkBytes) {
        throw new Error(`Missing chunk #${i} during reconstruction.`);
      }
      parts.push(chunkBytes);
    }

    // Assemble Blob
    const reconstructedBlob = new Blob(parts, { type: fileMetadata.fileType });
    const reconstructedBuffer = await reconstructedBlob.arrayBuffer();

    // Verify SHA-256 Hash
    setReceiverState(ReceiverState.VERIFYING);
    const computedHash = await computeSHA256(reconstructedBuffer);

    console.log('Sender hash:    ', fileMetadata.fileHash);
    console.log('Computed hash:  ', computedHash);

    if (computedHash.toLowerCase() === fileMetadata.fileHash.toLowerCase()) {
      // Hash verification SUCCEEDED!
      setReceiverState(ReceiverState.COMPLETED);
      
      // Play completion melody
      if (chkAudioFeedback.checked) {
        playNotificationChirp(523, 0.08);
        setTimeout(() => playNotificationChirp(659, 0.08), 100);
        setTimeout(() => playNotificationChirp(784, 0.14), 200);
      }

      // Populate completion card
      finalFileName.textContent = fileMetadata.fileName;
      finalFileSize.textContent = formatBytes(reconstructedBlob.size);
      finalFileHash.textContent = computedHash;

      // Revoke previous object URL if any
      if (reconstructedBlobUrl) {
        URL.revokeObjectURL(reconstructedBlobUrl);
      }

      reconstructedBlobUrl = URL.createObjectURL(reconstructedBlob);
      btnDownloadFile.href = reconstructedBlobUrl;
      btnDownloadFile.download = fileMetadata.fileName;

      // Show download card
      downloadCard.style.display = 'block';
      downloadCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      // Hash verification FAILED
      setReceiverState(ReceiverState.ERROR);
      verificationBanner.className = 'alert-box alert-danger';
      verificationBanner.innerHTML = `
        <div class="alert-icon">✗</div>
        <div class="alert-content">
          <strong>File Integrity Verification Failed!</strong>
          <p>The reconstructed file's SHA-256 (${computedHash.substring(0, 16)}...) did not match the sender hash (${fileMetadata.fileHash.substring(0, 16)}...). The file may be corrupt.</p>
        </div>
      `;
      downloadCard.style.display = 'block';
      btnDownloadFile.style.display = 'none';
    }
  } catch (err) {
    console.error('Reconstruction error:', err);
    setReceiverState(ReceiverState.ERROR);
    alert('File reconstruction failed: ' + err.message);
  }
}

/**
 * Resets receiver state for a new transfer.
 */
function resetTransfer() {
  currentTransferId = null;
  fileMetadata = null;
  receivedChunks.clear();
  duplicateScans = 0;
  
  if (reconstructedBlobUrl) {
    URL.revokeObjectURL(reconstructedBlobUrl);
    reconstructedBlobUrl = null;
  }

  transferProgressCard.style.display = 'none';
  downloadCard.style.display = 'none';
  missingChunksBox.style.display = 'none';
  rxProgressBar.style.width = '0%';
  duplicateCounterText.textContent = 'Duplicate scans skipped: 0';
  setReceiverState(isScanning ? ReceiverState.SCANNING : ReceiverState.WAITING);
}

// -------------------------------------------------------------
// Event Listeners Setup
// -------------------------------------------------------------

btnStartCamera.addEventListener('click', startCamera);
btnStopCamera.addEventListener('click', stopCamera);
btnResetTransfer.addEventListener('click', resetTransfer);
btnReceiveAnother.addEventListener('click', () => {
  resetTransfer();
  startCamera();
});

cameraSelect.addEventListener('change', () => {
  if (isScanning) {
    stopCamera().then(() => startCamera());
  }
});

// Initialize cameras on page load
window.addEventListener('DOMContentLoaded', () => {
  setReceiverState(ReceiverState.WAITING);
  enumerateCameras();
});

// Cleanup media resources on page unload
window.addEventListener('beforeunload', () => {
  stopCamera();
  if (reconstructedBlobUrl) {
    URL.revokeObjectURL(reconstructedBlobUrl);
  }
});
